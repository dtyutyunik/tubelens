"use strict";
(() => {
  // src/lib/quota.ts
  var DAILY_BUDGET = 1e4;
  var SAFETY_MARGIN = 500;
  var COST = {
    search: 100,
    // search.list
    list: 1
    // channels.list, playlistItems.list, videos.list
  };
  function pacificDateKey(d = /* @__PURE__ */ new Date()) {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: "America/Los_Angeles",
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).formatToParts(d);
    const get = (t) => parts.find((p) => p.type === t)?.value ?? "";
    return `${get("year")}-${get("month")}-${get("day")}`;
  }
  function estimateLookupCost(seedVideos) {
    return 2 * COST.list + seedVideos * COST.search + 2 * COST.list;
  }
  function canSpendPure(used, cost) {
    return used + cost <= DAILY_BUDGET - SAFETY_MARGIN;
  }
  var USAGE_KEY = "tubelens:quota";
  async function getUsage() {
    const stored = await chrome.storage.local.get(USAGE_KEY);
    const rec = stored[USAGE_KEY];
    const today = pacificDateKey();
    if (!rec || rec.date !== today) return { date: today, used: 0 };
    return rec;
  }
  async function canSpend(cost) {
    const { used } = await getUsage();
    return canSpendPure(used, cost);
  }
  async function recordSpend(cost) {
    const { date, used } = await getUsage();
    const next = { date, used: used + cost };
    await chrome.storage.local.set({ [USAGE_KEY]: next });
    return next;
  }

  // src/lib/youtube-api.ts
  var API_BASE = "https://www.googleapis.com/youtube/v3";
  var YouTubeApiError = class extends Error {
    code;
    status;
    constructor(code, status, message) {
      super(message);
      this.code = code;
      this.status = status;
    }
  };
  async function apiGet(path, params, apiKey) {
    const url = new URL(`${API_BASE}${path}`);
    for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
    url.searchParams.set("key", apiKey);
    let res;
    try {
      res = await fetch(url.toString());
    } catch (e) {
      throw new YouTubeApiError("NETWORK", 0, `Network error calling ${path}: ${String(e)}`);
    }
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      const reason = body?.error?.errors?.[0]?.reason;
      const message = body?.error?.message ?? `YouTube API error ${res.status}`;
      if (res.status === 400 || res.status === 401 || reason === "keyInvalid") {
        throw new YouTubeApiError("INVALID_KEY", res.status, "API key is invalid. Check it on the options page.");
      }
      if (res.status === 403 && reason === "quotaExceeded") {
        throw new YouTubeApiError("QUOTA_EXCEEDED", 403, "Daily YouTube API quota exceeded. Resets at midnight Pacific.");
      }
      if (res.status === 403) {
        throw new YouTubeApiError("INVALID_KEY", 403, `Access forbidden: ${message}`);
      }
      if (res.status === 429) {
        throw new YouTubeApiError("RATE_LIMITED", 429, "Rate limited \u2014 try again in a minute.");
      }
      throw new YouTubeApiError("UNKNOWN", res.status, message);
    }
    return await res.json();
  }
  async function getUploadsPlaylistId(apiKey, channelId) {
    const data = await apiGet("/channels", {
      part: "contentDetails",
      id: channelId
    }, apiKey);
    const uploads = data.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
    if (!uploads) throw new YouTubeApiError("UNKNOWN", 200, "Could not find uploads playlist for channel.");
    return uploads;
  }
  async function getRecentVideoIds(apiKey, playlistId, n) {
    const data = await apiGet("/playlistItems", {
      part: "contentDetails",
      playlistId,
      maxResults: String(n)
    }, apiKey);
    return (data.items ?? []).map((i) => i.contentDetails?.videoId).filter((v) => !!v);
  }
  async function getRelatedChannelIds(apiKey, videoId, maxResults) {
    const data = await apiGet("/search", {
      part: "snippet",
      relatedToVideoId: videoId,
      type: "video",
      maxResults: String(maxResults)
    }, apiKey);
    return (data.items ?? []).map((i) => i.snippet?.channelId).filter((c) => !!c);
  }
  async function getChannelStats(apiKey, channelIds) {
    const out = /* @__PURE__ */ new Map();
    for (let i = 0; i < channelIds.length; i += 50) {
      const batch = channelIds.slice(i, i + 50);
      const data = await apiGet("/channels", {
        part: "snippet,statistics",
        id: batch.join(",")
      }, apiKey);
      for (const item of data.items ?? []) {
        out.set(item.id, {
          channelId: item.id,
          title: item.snippet?.title ?? item.id,
          thumbnail: item.snippet?.thumbnails?.default?.url ?? "",
          subscriberCount: Number(item.statistics?.subscriberCount ?? 0),
          viewCount: Number(item.statistics?.viewCount ?? 0),
          videoCount: Number(item.statistics?.videoCount ?? 0)
        });
      }
    }
    return out;
  }
  async function testApiKey(apiKey) {
    await apiGet("/channels", { part: "id", id: "UC_x5XG1OV2P6uZZ5FSM9Ttw" }, apiKey);
    return true;
  }

  // src/lib/types.ts
  var DEFAULT_SETTINGS = {
    apiKey: "",
    maxSubs: 5e4,
    maxResults: 12,
    autoRun: true
  };

  // src/lib/settings.ts
  var KEY = "tubelens:settings";
  async function getSettings() {
    const stored = await chrome.storage.local.get(KEY);
    return { ...DEFAULT_SETTINGS, ...stored[KEY] };
  }
  async function saveSettings(patch) {
    const next = { ...await getSettings(), ...patch };
    await chrome.storage.local.set({ [KEY]: next });
    return next;
  }

  // src/lib/cache.ts
  var PREFIX = "tubelens:similar:";
  var INDEX_KEY = "tubelens:cache-index";
  var TTL_MS = 7 * 24 * 60 * 60 * 1e3;
  var MAX_ENTRIES = 200;
  function keyFor(channelId) {
    return `${PREFIX}${channelId}`;
  }
  async function getIndex() {
    const stored = await chrome.storage.local.get(INDEX_KEY);
    return stored[INDEX_KEY] ?? [];
  }
  async function touchIndex(key) {
    const index = (await getIndex()).filter((k) => k !== key);
    index.unshift(key);
    const evicted = index.splice(MAX_ENTRIES);
    if (evicted.length > 0) await chrome.storage.local.remove(evicted);
    await chrome.storage.local.set({ [INDEX_KEY]: index });
  }
  async function getCachedSimilar(channelId) {
    const key = keyFor(channelId);
    const stored = await chrome.storage.local.get(key);
    const entry = stored[key];
    if (!entry) return null;
    if (Date.now() - entry.fetchedAt > TTL_MS) return null;
    await touchIndex(key);
    return entry.channels;
  }
  async function setCachedSimilar(channelId, channels) {
    const key = keyFor(channelId);
    const entry = { fetchedAt: Date.now(), channels };
    await chrome.storage.local.set({ [key]: entry });
    await touchIndex(key);
  }
  async function deleteCachedSimilar(channelId) {
    await chrome.storage.local.remove(keyFor(channelId));
  }
  async function getCachedEntry(channelId) {
    const key = keyFor(channelId);
    const stored = await chrome.storage.local.get(key);
    const entry = stored[key];
    return entry ? { channels: entry.channels, fetchedAt: entry.fetchedAt } : null;
  }

  // src/lib/similarity.ts
  function rankChannels(seedChannelId, relatedLists, stats, opts) {
    const seeds = relatedLists.length;
    const appearances = /* @__PURE__ */ new Map();
    for (const list of relatedLists) {
      for (const id of new Set(list)) {
        if (id === seedChannelId) continue;
        appearances.set(id, (appearances.get(id) ?? 0) + 1);
      }
    }
    const ranked = [];
    for (const [channelId, count] of appearances) {
      const s = stats.get(channelId);
      if (!s) continue;
      if (s.subscriberCount > opts.maxSubs) continue;
      ranked.push({ ...s, appearances: count, seeds });
    }
    ranked.sort((a, b) => b.appearances - a.appearances || b.viewCount - a.viewCount);
    return ranked.slice(0, opts.maxResults);
  }

  // src/lib/pipeline.ts
  var NoVideosError = class extends Error {
    constructor() {
      super("This channel has no public videos to seed from.");
      this.name = "NoVideosError";
    }
  };
  var NoRelatedDataError = class extends Error {
    failedSeeds;
    constructor(failedSeeds) {
      super(
        `Could not load related videos for any seed video (${failedSeeds} failed). They may be private, deleted, or region-restricted.`
      );
      this.name = "NoRelatedDataError";
      this.failedSeeds = failedSeeds;
    }
  };
  async function buildSimilarChannels(api, channelId, opts) {
    const playlistId = await api.getUploadsPlaylistId(channelId);
    const videoIds = await api.getRecentVideoIds(playlistId, opts.seedVideos);
    if (videoIds.length === 0) throw new NoVideosError();
    const relatedLists = [];
    let seedsFailed = 0;
    for (const vid of videoIds) {
      try {
        relatedLists.push(await api.getRelatedChannelIds(vid, opts.relatedPerVideo));
      } catch {
        seedsFailed += 1;
      }
    }
    const usable = relatedLists.filter((l) => l.length > 0);
    if (usable.length === 0) throw new NoRelatedDataError(seedsFailed);
    const unique = [...new Set(usable.flat())].filter((id) => id !== channelId);
    const stats = await api.getChannelStats(unique);
    const channels = rankChannels(channelId, usable, stats, {
      maxSubs: opts.maxSubs,
      maxResults: opts.maxResults
    });
    return { channels, seedsUsed: usable.length, seedsFailed };
  }

  // src/background/service-worker.ts
  var SEED_VIDEOS = 5;
  var RELATED_PER_VIDEO = 25;
  var BETWEEN_CALLS_MS = 150;
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function handleGetSimilar(channelId, forceRefresh = false) {
    const settings = await getSettings();
    if (!settings.apiKey) {
      return { error: "NO_API_KEY", message: "Set your YouTube API key on the options page." };
    }
    if (forceRefresh) await deleteCachedSimilar(channelId);
    const cached = await getCachedSimilar(channelId);
    if (cached) {
      const usage = await getUsage();
      const entry = await getCachedEntry(channelId);
      return {
        channels: cached,
        cached: true,
        quota: { used: usage.used, budget: DAILY_BUDGET },
        fetchedAt: entry?.fetchedAt
      };
    }
    const estimate = estimateLookupCost(SEED_VIDEOS);
    if (!await canSpend(estimate)) {
      const stale = await getCachedEntry(channelId);
      const usage = await getUsage();
      if (stale) {
        return {
          channels: stale.channels,
          cached: true,
          stale: true,
          fetchedAt: stale.fetchedAt,
          quota: { used: usage.used, budget: DAILY_BUDGET }
        };
      }
      return {
        error: "QUOTA_EXHAUSTED",
        message: `Estimated ${estimate} units needed, only ${DAILY_BUDGET - usage.used} left today. Quota resets at midnight Pacific.`
      };
    }
    let statsUnits = 0;
    const api = {
      getUploadsPlaylistId: (cid) => getUploadsPlaylistId(settings.apiKey, cid),
      getRecentVideoIds: (pid, n) => getRecentVideoIds(settings.apiKey, pid, n),
      getRelatedChannelIds: async (vid, n) => {
        try {
          return await getRelatedChannelIds(settings.apiKey, vid, n);
        } finally {
          await sleep(BETWEEN_CALLS_MS);
        }
      },
      getChannelStats: async (ids) => {
        statsUnits = Math.max(1, Math.ceil(ids.length / 50)) * COST.list;
        return getChannelStats(settings.apiKey, ids);
      }
    };
    try {
      const { channels, seedsUsed, seedsFailed } = await buildSimilarChannels(api, channelId, {
        seedVideos: SEED_VIDEOS,
        relatedPerVideo: RELATED_PER_VIDEO,
        maxSubs: settings.maxSubs,
        maxResults: settings.maxResults
      });
      const spent = 2 * COST.list + (seedsUsed + seedsFailed) * COST.search + statsUnits;
      await recordSpend(spent);
      await setCachedSimilar(channelId, channels);
      const usage = await getUsage();
      return {
        channels,
        cached: false,
        quota: { used: usage.used, budget: DAILY_BUDGET },
        degraded: seedsFailed > 0 ? { seedsUsed, seedsFailed } : void 0
      };
    } catch (e) {
      if (e instanceof NoVideosError || e instanceof NoRelatedDataError) {
        return { error: "API_ERROR", message: e.message };
      }
      if (e instanceof YouTubeApiError) {
        if (e.code === "QUOTA_EXCEEDED") {
          return { error: "QUOTA_EXHAUSTED", message: e.message };
        }
        if (e.code === "INVALID_KEY") {
          return { error: "NO_API_KEY", message: e.message };
        }
        return { error: "API_ERROR", message: e.message };
      }
      return { error: "API_ERROR", message: String(e) };
    }
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    (async () => {
      switch (msg?.type) {
        case "TUBELENS_GET_SIMILAR":
          return handleGetSimilar(msg.channelId, msg.forceRefresh === true);
        case "TUBELENS_GET_SETTINGS":
          return { settings: await getSettings() };
        case "TUBELENS_SAVE_SETTINGS":
          return { settings: await saveSettings(msg.patch) };
        case "TUBELENS_TEST_KEY":
          try {
            await testApiKey(msg.apiKey);
            return { ok: true };
          } catch (e) {
            return { ok: false, message: e instanceof Error ? e.message : String(e) };
          }
        case "TUBELENS_GET_QUOTA": {
          const usage = await getUsage();
          return { used: usage.used, budget: DAILY_BUDGET, date: usage.date };
        }
        default:
          return { error: "UNKNOWN_MESSAGE" };
      }
    })().then(sendResponse);
    return true;
  });
})();
